Gambo is a HTML5 & CSS3 responsive Bootstrap 4 template created for Plateform but also can be used for generalised website. Gambo is an attractive html template specially designed for the multipurpose shops like mega store, grocery store, supermarket, organic shop, and online stores selling products like beverages, vegetables, fruits, ice creams, paste, herbs, juice, meat, cold drinks, sausages, mocktails, soft drinks, cookies…,and It’s 100% super responsive and it works nicely on smartphones, tablet, & desktops. Designed on grid system, your site will look sharp on all screens. Our package includes 39 well-organized HTML files.


Features :-

- 39 Html Files
- Fully Boostrap 4
- Semantic UI
- Unique Homepage
- Single Product Detail Page
- Dashbaord
- Product Request Page
- Offers Page
- My Rewards Page
- Order Placed
- Bill
- Checkout Page
- Career Page
- Login Page
- Validator.w3.org/
- Creative and unique design
- Designed on 1170px Grid System
- Pixel perfect
- Free Google Fonts
- Free Font Awesome Icons
- Free Unicons Icons
- Free Svg Based Icons


Fonts used :-

Rajdhani: https://fonts.google.com/specimen/Rajdhani

Icon Used :-

FontAwesome: https://fontawesome.com/
Flaticons: https://www.flaticon.com/
Unicons: https://iconscout.com/unicons/

IMPORTANT!!! All Images are from different resources and they are not included to Html files.


Pixel Dimensions: 1920x3500

Tags:  	Delivery, eatables, ecommerce, electronics, food delivery, Food Store, fruits,  Grocery & Staples, Grocery, market, nuts, organic, shopping, supermarket, vegetables